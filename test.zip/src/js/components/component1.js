const a = 1
const b = 3 
console.log(a+b)