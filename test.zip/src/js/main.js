const obj = {}
const prop = obj?.prop
console.log(obj)
