const { src, dest, series, watch } = require('gulp')
const concat = require('gulp-concat')
const htmlMin = require('gulp-htmlmin')
const autoprefixes = require('gulp-autoprefixer')
const cleanCSS = require('gulp-clean-css')
const svgSprite = require('gulp-svg-sprite')
const image = require('gulp-image')
const babel = require('gulp-babel')
const notify = require('gulp-notify')
const uglify = require('gulp-uglify-es').default
const sourcemaps = require('gulp-sourcemaps')
const del = require('del')
const gulpif = require('gulp-if')
const argv = require('yargs').argv
const browserSync = require('browser-sync').create()

const clean = () => {
    return del(['dist'])
}

const resourses = () => {
    return src ('src/**')
    .pipe(dest('dist'))
}

const styles = () => {
    return src ('src/**/*.css')
    .pipe(gulpif(argv.prod, concat('main.css')))
    .pipe(gulpif(argv.prod, autoprefixes({
        cascade: false
    })))
    .pipe(gulpif(argv.prod, cleanCSS({
        level:2
    })))
    .pipe(dest('dist'))
}

const styles1 = () => {
    return src ('src/**/*.css')
    .pipe(sourcemaps.init())
    .pipe(sourcemaps.write())
    .pipe(dest('dist'))
    .pipe(browserSync.stream())
}
 
const htmlMinify = () => {
    return src ('src/**/*.html')
    .pipe(gulpif(argv.prod, htmlMin({
        collapseWhitespace: true,
    })))
    .pipe(dest('dist'))
}

const htmlMinify1 = () => {
    return src ('src/**/*.html')
    .pipe(dest('dist'))
    .pipe(browserSync.stream())
}

const svgSprites = () => {
    return src ('src/**/*.svg')
    .pipe(svgSprite({
        mode: {
            stack: {
                sprite: '../sprite.svg'
            }
        }
    })) 
    .pipe(dest('dist/images'))
}

const scripts = () => {
    return src ('src/*.js')
    .pipe(gulpif(argv.prod, babel({ 
        presets: ['@babel/env']
    })))
    .pipe(gulpif(argv.prod, concat('app.js')))
    .pipe(gulpif(argv.prod, uglify({
        toplevel:true}).on('error', notify.onError())))
    .pipe(dest('dist'))
}

const scripts1 = () => {
    return src ('src/*.js')
    .pipe(sourcemaps.init())
    .pipe(sourcemaps.write())
    .pipe(dest('dist'))
    .pipe(browserSync.stream())
} 

const watchFiles = () => {
    browserSync.init({
        server: {
            baseDir: 'dist'
        }
    })
}

const images = () => {
    return src ([
        'src/**/*.png',
        'src/**/*.ico',
        ])
    .pipe(image())
    .pipe(dest('dist'))    
}

watch('src/**/*.html', htmlMinify)
watch('src/**/*.css', styles)
watch('src/**/*.svg', svgSprites)
watch('src/*.js', scripts)
watch('src/**', resourses)

exports.styles1 = styles1
exports.scripts1 = scripts1
exports.htmlMinify1 = htmlMinify1
exports.clean = clean
exports.default = series(clean, resourses, htmlMinify, scripts, styles, images, watchFiles, svgSprites)
exports.dev = series(clean, resourses, htmlMinify1, scripts1, styles1, images, watchFiles, svgSprites)
exports.prod = series(clean, resourses, htmlMinify, scripts, styles, images, svgSprites)


