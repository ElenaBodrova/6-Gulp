//Инициализация Swiper
new Swiper('.image-slider', {
	//Стрелки
	navigation: {
		nextEl: '.btn-nxt',
		prevEl: '.btn-prv'
	},
	pagination: {
		el: '.swiper-pagination',
		clickable: true,
	},	
	//Включение/отключение перетаскивания на ПК
	simulateTouch: true,

	//Управление клавиатурой
	keyboard: {
	 	//Включить/выключить 
	 	enabled: true,
		//Включить/выключить управление клавишами pageUp pagedown
		pageUpdown:true,
	 },

	//Бесконечный слайдер
	loop: true,

	//Количество слайдов для показа
	slidesPerView: 1,

	//Адаптивность
	breakpoints: {    
		320: {
			slidesPerView: 1,
			spaceBetween: 20,
		},
		880: {
			slidesPerView: 2,
			spaceBetween: 30,
		},
		1121: {
			slidesPerView: 3,
			spaceBetween: 10,
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
		}
	}
});

// Получить модальный
var modal = document.getElementById("myModal");
var modal_menu = document.getElementById("modal_menu");
var close_menu = document.getElementById("close_menu");

// Получить кнопку, которая открывает модальный
var btn = document.getElementById("myBtn");
var btn1 = document.getElementById("myBtn1");
var btn2 = document.getElementById("myBtn2");
var btn3 = document.getElementById("myBtn3");
var btn4 = document.getElementById("myBtn4");

// Получить элемент <span>, который закрывает модальный
var span = document.getElementsByClassName("close")[0];
var span1 = document.getElementsByClassName("close_menu")[0];

// Когда пользователь нажимает на кнопку, откройте модальный
btn.onclick = function() {
	modal.style.display = "block";
}
btn1.onclick = function() {
	modal.style.display = "block";
}
btn2.onclick = function() {
	modal.style.display = "block";
}
btn4.onclick = function() {
	modal.style.display = "block";
}
btn3.onclick = function() {
	modal_menu.style.display = "block";
	close_menu.style.display = "block"; 
}
// Когда пользователь нажимает на <span> (x), закройте модальное окно
span.onclick = function() {
	modal.style.display = "none";
}
span1.onclick = function() {
	modal_menu.style.display = "none";
	close_menu.style.display = "none";
}